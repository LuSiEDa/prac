from flask import request, jsonify
from flask_smorest import Blueprint
from flask.views import MethodView
from routes.db import db
from models import Board

board_blp = Blueprint('Boards', 'boards', descriotion='Operations on boards', url_prefix='/boards')

# API List
# 전체 게시글 불러오기 (GET)
# 게시글 작성 (POST)
@board_blp.route('/')
class BoardList(MethodView):
    def get(self):
        boards = Board.query.all()
        # "SELECT * FROM users LEFT JOIN tables" 이런거 안해도 한 줄로 오케이!

        return jsonify([
            {
                "id":board.id, 
                "title":board.title, 
                "content":board.content,
                "author_name":board.author.name
            } 
            for board in boards
        ])

    def post(self):
        data = request.json
        new_board = Board(title=data['title'], content=data['content'], user_id=data['user_id'])
        db.session.add(new_board)
        db.session.commit()
        
        return jsonify({'msg':'success create board'}), 201


# /board/<int:board_id>
# 하나의 게시글 불러오기 (GET)
@board_blp.route("/<int: board_id>")
class BoardResource(MethodView):
    def get(self, board_id):
        board = Board.query.get_or_404(board_id)
        return jsonify({'id':board.id,
                        'title': board.title,
                        'content':board.content,
                        'author_name':board.author.name
                        })

# 특정 게시글 수정하기 (PUT)
    def put(self, board_id):
        board = Board.query.get_or_404(board_id)
        data = request.json
        
        board.title = data['title']
        board.content = data['content']
        db.session.commit()
        return jsonify({'msg':'Successfully updated board data'}), 201

# 특정 게시글 삭제하기 (DELETE)
    def delete(self, board_id):
        board = Board.query.get_or_404(board_id)
        db.session.delete(board)
        db.session.commit()
        
        return jsonify({'msg':'success delete board'}), 204



