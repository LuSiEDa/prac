from flask import Flask, render_template
from flask_smorest import Api
import pymysql
from posts_route import create_posts_blueprint

import yaml

app = Flask(__name__)

db_info = yaml.load(open('db.yaml'), Loader=yaml.FullLoader)
app.config["MYSQL_HOST"] = db_info['mysql_host']
app.config["MYSQL_USER"]= db_info['mysql_user']
app.config["MYSQL_PASSWORD"] = db_info['mysql_password']
app.config["MYSQL_DB"] = db_info['mysql_db']

# PyMySQL은 Flask 확장이 아니므로 직접 커넥션 만들어서 전달해야 함
def get_connection():
    return pymysql.connect(
        host=app.config["MYSQL_HOST"],
        user=app.config["MYSQL_USER"],
        password=app.config["MYSQL_PASSWORD"],
        db=app.config["MYSQL_DB"],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )
# Flask 앱 인스턴스를 MySQL 객체에 연결(바인딩)
# mysql = MySQL(app)
# 버젼 호환 이슈로 pymysql로 대체하기로 함.

# blueprint 설정
app.config["API_TITLE"] = "Blog API List"
app.config["API_VERSION"] = "1.0"
app.config["OPENAPI_VERSION"] = "3.1.3"
app.config["OPENAPI_URL_PREFIX"] = "/"
app.config["OPENAPI_SWAGGER_UI_PATH"] = "/swagger-ui"
app.config["OPENAPI_SWAGGER_UI_URL"] = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"

api = Api(app)
posts_blp = create_posts_blueprint(get_connection)
api.register_blueprint(posts_blp)

from flask import render_template
@app.route('/blogs')
def manage_blogs():
    return render_template("posts.html")

if __name__ == "__main__":
    app.run(debug=True)